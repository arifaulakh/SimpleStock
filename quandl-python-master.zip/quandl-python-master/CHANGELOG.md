### 3.1.0 - 2017-03-07

* Bug: support column with a name 'code'


### 3.0.1 - 2016-05-25

* Handle unexpected errors

### 3.0.0 - 2016-04-22

* Datatables for developers
* Datatables for analysts
* Backwards compatibility
* Documentation updates